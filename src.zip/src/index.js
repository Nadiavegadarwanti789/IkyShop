const { Telegraf } = require('telegraf');
const kucoin = require('kucoin-api');

// Konfigurasi API KuCoin
const apiKey = '67f1064a0db26300011b681c';
const apiSecret = 'dd2d827c-b313-4081-9d18-ef016477a948';
const apiPassphrase = 'BotSaya123456';

// Buat instance KuCoin
const kucoinClient = new kucoin.Client({
  apiKey,
  apiSecret,
  apiPassphrase,
});

// Buat instance bot Telegram
const bot = new Telegraf(' 7298324862:AAHuGizpnm1dEewFznqj60wrstyZD4vQIQk ');

// Menu produk
bot.command('produk', (ctx) => {
  const produkList = [
    { id: 1, name: 'Backpack', price: 50.000 },
    { id: 2, name: 'Mexc', price: 50.000 },
    { id: 3, name: 'Binance', price: 70.000 },
    { id: 4, name: 'Galxe', price: 50.000 },
    { id: 5, name: 'Bybit', price: 70.000 },
    { id: 6, name: 'Huobi', price: 50.000 },
    { id: 7, name: 'Bitget', price: 50.000 },
    { id: 8, name: 'Holonym', price: 50.000 },
    { id: 9, name: 'Sanbox', price: 50.000 },
    { id: 10, name: 'Gate io', price: 50.000 },
  ];

  ctx.reply('Menu Produk:', {
    reply_markup: {
      inline_keyboard: produkList.map((produk) => [
        {
          text: produk.name,
          callback_data: `produk_${produk.id}`,
        },
      ]),
    },
  });
});

// Tombol "Beli Sekarang"
bot.action(/produk_(.+)/, (ctx) => {
  const produkId = ctx.match[1];
  const produk = [
    { id: 1, name: 'Backpack', price: 50.000 },
    { id: 2, name: 'Mexc', price: 50.000 },
    { id: 3, name: 'Binance', price: 70.000 },
    { id: 4, name: 'Galxe', price: 50.000 },
    { id: 5, name: 'Bybit', price: 70.000 },
    { id: 6, name: 'Huobi', price: 50.000 },
    { id: 7, name: 'Bitget', price: 50.000 },
    { id: 8, name: 'Holonym', price: 50.000 },
    { id: 9, name: 'Sanbox', price: 50.000 },
    { id: 10, name: 'Gate io', price: 50.000 },
  ].find((p) => p.id === parseInt(produkId));

  if (produk) {
    ctx.reply(`Anda telah memilih ${produk.name}. Silakan melakukan pembayaran.`, {
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: 'Bayar Sekarang',
              callback_data: `bayar_${produk.id}`,
            },
          ],
        ],
      },
    });
  } else {
    ctx.reply('Produk tidak ditemukan.');
  }
});

// Pembayaran
bot.action(/bayar_(.+)/, async (ctx) => {
  const produkId = ctx.match[1];
  const produk = [
    { id: 1, name: 'Backpack', price: 50000 },
    { id: 2, name: 'Mexc', price: 50000 },
    { id: 3, name: 'Binance', price: 70000 },
    { id: 4, name: 'Galxe', price: 50000 },
    { id: 5, name: 'Bybit', price: 70000 },
    { id: 6, name: 'Huobi', price: 50000 },
    { id: 7, name: 'Bitget', price: 50000 },
    { id: 8, name: 'Holonym', price: 50000 },
    { id: 9, name: 'Sanbox', price: 50000 },
    { id: 10, name: 'Gate io', price: 50000 },
  ].find((p) => p.id === parseInt(produkId));

  if (produk) {
    try {
      // Buat order pembelian
      const order = await kucoinClient.createOrder({
        symbol: 'BTC-USDT',
        side: 'buy',
        type: 'limit',
        quantity: 1,
        price: produk.price,
      });

// Cek status order
const status = await kucoinClient.getOrderStatus(order.id);

if (status === 'done') {
ctx.reply('Transaksi berhasil!');
} else {
ctx.reply('Transaksi gagal.');
}
} catch (error) {
ctx.reply('Transaksi gagal.');
console.error(error);
}
} else {
ctx.reply('Produk tidak ditemukan.');
}
});

// Jalankan bot
bot.launch();